<html>
<head>
<title>ChartDirector Ver 4.1 Sample Programs</title>
</head>
<FRAMESET ROWS="19,*" FRAMESPACING="0">
    <FRAME
      NAME="indextop"
      SRC="indextop.php"
      SCROLLING="no"
      FRAMEBORDER="YES"
      BORDER="0"
    >
    <FRAMESET COLS="220,*" FRAMESPACING="0">
        <FRAME
                NAME="indexleft"
                SRC="indexleft.php"
                SCROLLING="auto"
                FRAMEBORDER="YES"
        >
        <FRAME
                NAME="indexright"
                SRC="indexright.php"
                SCROLLING="auto"
                FRAMEBORDER="YES"
        >
    </FRAMESET>
</FRAMESET>
</html>

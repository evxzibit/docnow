<html>
<body bgColor="#000080" topmargin="0" leftmargin="0" rightmargin="0" marginwidth="0" marginheight="0">
<div style="margin-left:1; font-size:9pt; font-family:verdana; font-weight:bold; color:#FFFF00;"><i>ChartDirector Ver 4.1 Sample Programs</i></div>
</body>
</html>
